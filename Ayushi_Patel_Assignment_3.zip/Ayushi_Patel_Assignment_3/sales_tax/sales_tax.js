var $ = function (id) {
    return document.getElementById(id);
};

var processEntries = function processEntries() { 
    var subTotal = parseFloat($("subtotal").value);
    var taxRate = parseFloat($("tax_rate").value);

    if ((subTotal > 0 && subTotal < 10000) && (taxRate > 0 && taxRate < 12)) {
        alert("Subtotal must be > 0 and < 10000 \nTax Rate must be > 0 and < 12");
    }

    var salesTax = subTotal * taxRate / 100;
    $("sales_tax").value = salesTax;

    var total = subTotal + salesTax;
    $("total").value = total;
    return;
}

function clear() {
    $("subtotal").value = '';
    $("tax_rate").value = '';
    $("sales_tax").value = '';
    $("total").value = '';

    $("subtotal").focus();
    return;
}

window.onload = function (){
    $("calculate").onclick = processEntries;
    $("clear").onclick = clear;
    $("subtotal").focus();
};