"use strict";
var $ = function (id) {
    return document.getElementById(id);
};
var calculatetax = function () {
    var total;
    var income = parseFloat($("income").value);
    $("tax").value = calculatetaxes(income);
    function calculatetaxes(amount) {
        var i = 0;
        if (amount > 37650 || amount <= 91150) {
            tax = ((amount - 9275) * 0.15) + 927.50;
        }
        else if (amount > 0 || amount <= 9275) {
            tax = ((amount - 0)) * 0.10 + 0;
        }
        return tax;
    }
}


window.onload = function () {
    $("tax").onclick =calculatetax; 
};